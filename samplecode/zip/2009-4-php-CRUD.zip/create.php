<form method="post" action="create_submit.php">
	<p>제목: <input type="text" name="title" /></p>
	<p>작성자: <input type="text" name="author" /></p>
	<p><input type="submit" value=" 작 성 " /></p>
</form>